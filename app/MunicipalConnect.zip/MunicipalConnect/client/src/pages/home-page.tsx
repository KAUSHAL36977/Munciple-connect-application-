import { useAuth } from "@/hooks/use-auth";
import Navbar from "@/components/navbar";
import ComplaintForm from "@/components/complaint-form";
import ComplaintList from "@/components/complaint-list";
import AnnouncementBoard from "@/components/announcement-board";

export default function HomePage() {
  const { user } = useAuth();

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto p-6 space-y-8">
        <div className="grid gap-6 md:grid-cols-2">
          <div className="space-y-6">
            <h1 className="text-3xl font-bold">Welcome, {user?.username}!</h1>
            <ComplaintForm />
            <ComplaintList />
          </div>
          <div>
            <AnnouncementBoard />
          </div>
        </div>
      </main>
    </div>
  );
}
