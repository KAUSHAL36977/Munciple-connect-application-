import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import {
  Building2,
  HomeIcon,
  ClipboardList,
  LogOut,
} from "lucide-react";

export default function Navbar() {
  const { user, logoutMutation } = useAuth();

  return (
    <nav className="border-b bg-gradient-to-b from-background to-muted/50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link href="/">
          <div className="flex items-center gap-2 cursor-pointer group">
            <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
              <Building2 className="h-6 w-6 text-primary" />
            </div>
            <span className="text-lg font-semibold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              Municipal Connect
            </span>
          </div>
        </Link>

        <div className="flex items-center gap-4">
          <Link href="/">
            <Button variant="ghost" className="gap-2 hover:bg-primary/10">
              <HomeIcon className="h-4 w-4" />
              Home
            </Button>
          </Link>

          {user?.isAdmin && (
            <Link href="/admin">
              <Button variant="ghost" className="gap-2 hover:bg-primary/10">
                <ClipboardList className="h-4 w-4" />
                Admin
              </Button>
            </Link>
          )}

          <Button
            variant="ghost"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            className="gap-2 hover:bg-destructive/10 hover:text-destructive"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </Button>
        </div>
      </div>
    </nav>
  );
}