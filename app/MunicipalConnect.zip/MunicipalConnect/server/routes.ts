import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertComplaintSchema, insertAnnouncementSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  // Complaints
  app.post("/api/complaints", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const data = insertComplaintSchema.parse(req.body);
      const complaint = await storage.createComplaint({
        ...data,
        userId: req.user!.id,
      });
      res.status(201).json(complaint);
    } catch (error) {
      res.status(400).json({ error: "Invalid complaint data" });
    }
  });

  app.get("/api/complaints", async (req: Request, res: Response) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    if (req.user!.isAdmin) {
      const complaints = await storage.getComplaints();
      res.json(complaints);
    } else {
      const complaints = await storage.getComplaintsByUser(req.user!.id);
      res.json(complaints);
    }
  });

  app.patch("/api/complaints/:id/status", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.sendStatus(401);
    
    try {
      const complaint = await storage.updateComplaintStatus(
        parseInt(req.params.id),
        req.body.status
      );
      res.json(complaint);
    } catch (error) {
      res.status(404).json({ error: "Complaint not found" });
    }
  });

  // Announcements
  app.post("/api/announcements", async (req: Request, res: Response) => {
    if (!req.isAuthenticated() || !req.user!.isAdmin) return res.sendStatus(401);
    
    try {
      const data = insertAnnouncementSchema.parse(req.body);
      const announcement = await storage.createAnnouncement(data);
      res.status(201).json(announcement);
    } catch (error) {
      res.status(400).json({ error: "Invalid announcement data" });
    }
  });

  app.get("/api/announcements", async (_req: Request, res: Response) => {
    const announcements = await storage.getAnnouncements();
    res.json(announcements);
  });

  const httpServer = createServer(app);
  return httpServer;
}
