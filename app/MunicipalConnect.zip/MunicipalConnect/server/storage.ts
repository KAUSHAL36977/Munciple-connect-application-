import { User, InsertUser, Complaint, InsertComplaint, Announcement, InsertAnnouncement } from "@shared/schema";
import createMemoryStore from "memorystore";
import session from "express-session";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  createComplaint(complaint: InsertComplaint & { userId: number }): Promise<Complaint>;
  getComplaints(): Promise<Complaint[]>;
  getComplaintsByUser(userId: number): Promise<Complaint[]>;
  updateComplaintStatus(id: number, status: string): Promise<Complaint>;
  
  createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement>;
  getAnnouncements(): Promise<Announcement[]>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private complaints: Map<number, Complaint>;
  private announcements: Map<number, Announcement>;
  private currentId: number;
  sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.complaints = new Map();
    this.announcements = new Map();
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id, isAdmin: false };
    this.users.set(id, user);
    return user;
  }

  async createComplaint(complaint: InsertComplaint & { userId: number }): Promise<Complaint> {
    const id = this.currentId++;
    const newComplaint: Complaint = {
      ...complaint,
      id,
      status: 'pending',
      createdAt: new Date(),
    };
    this.complaints.set(id, newComplaint);
    return newComplaint;
  }

  async getComplaints(): Promise<Complaint[]> {
    return Array.from(this.complaints.values());
  }

  async getComplaintsByUser(userId: number): Promise<Complaint[]> {
    return Array.from(this.complaints.values()).filter(
      (complaint) => complaint.userId === userId,
    );
  }

  async updateComplaintStatus(id: number, status: string): Promise<Complaint> {
    const complaint = this.complaints.get(id);
    if (!complaint) throw new Error('Complaint not found');
    
    const updatedComplaint = { ...complaint, status };
    this.complaints.set(id, updatedComplaint);
    return updatedComplaint;
  }

  async createAnnouncement(announcement: InsertAnnouncement): Promise<Announcement> {
    const id = this.currentId++;
    const newAnnouncement: Announcement = {
      ...announcement,
      id,
      createdAt: new Date(),
    };
    this.announcements.set(id, newAnnouncement);
    return newAnnouncement;
  }

  async getAnnouncements(): Promise<Announcement[]> {
    return Array.from(this.announcements.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }
}

export const storage = new MemStorage();
